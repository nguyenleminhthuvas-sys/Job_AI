import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, getRoleHome, getRoleIcon } from '../AuthContext';
import { ROLES, type Role } from '../data';
import { Sparkles, Lock, Shield } from 'lucide-react';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [name, setName] = useState('');
  const [branch, setBranch] = useState('HCM - Nguyễn Thị Minh Khai');
  const [loading, setLoading] = useState(false);

  const BRANCHES = ['HN - Hàng Bài', 'HN - Kim Mã', 'HCM - Nguyễn Thị Minh Khai', 'HCM - Đinh Tiên Hoàng', 'HCM - Lê Văn Sỹ'];

  const handleLogin = async () => {
    if (!selectedRole || !name.trim()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    login(selectedRole, name.trim(), branch);
    navigate(getRoleHome(selectedRole));
  };

  const roles = Object.entries(ROLES) as [Role, typeof ROLES[Role]][];

  return (
    <div className="login-page">
      <div className="login-bg-glow" />
      <div className="login-bg-glow" />

      <div className="login-card animate-fade-up">
        <div className="login-header">
          <div className="login-logo" style={{ background: 'rgba(190, 146, 77, 0.08)', border: '1px solid rgba(190, 146, 77, 0.2)', boxShadow: 'none' }}>
            <Sparkles size={26} color="var(--gold-400)" strokeWidth={1.5} />
          </div>
          <div className="login-title" style={{ letterSpacing: '-0.02em', fontWeight: 600 }}>Saigon Smile Medical</div>
          <div className="login-sub">Hệ thống Quản lý Nội bộ</div>
        </div>

        {/* Role Selection */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-400)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 12 }}>
            Chọn vai trò
          </div>
          <div className="role-grid">
            {roles.map(([roleKey, cfg]) => (
              <div
                key={roleKey}
                className={`role-card ${selectedRole === roleKey ? 'selected' : ''}`}
                onClick={() => setSelectedRole(roleKey)}
                id={`role-${roleKey}`}
                style={{
                  padding: '16px 12px',
                  borderRadius: 'var(--r-md)',
                  borderWidth: '1px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  background: selectedRole === roleKey ? 'rgba(190, 146, 77, 0.05)' : 'rgba(255, 255, 255, 0.015)'
                }}
              >
                <div className="role-icon" style={{
                  color: selectedRole === roleKey ? 'var(--gold-400)' : 'var(--text-400)',
                  marginBottom: 8,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  height: 24
                }}>
                  {getRoleIcon(roleKey, undefined, 20)}
                </div>
                <div className="role-name" style={{ fontSize: 12, fontWeight: 500, color: selectedRole === roleKey ? 'var(--text-100)' : 'var(--text-300)' }}>{cfg.label}</div>
                <div className="role-desc" style={{ fontSize: 10, color: 'var(--text-400)', marginTop: 2 }}>{cfg.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Name Input */}
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-400)', textTransform: 'uppercase', letterSpacing: '0.08em', display: 'block', marginBottom: 8 }}>
            Họ và tên
          </label>
          <input
            className="input-field"
            type="text"
            placeholder="Nhập họ tên của bạn..."
            value={name}
            onChange={e => setName(e.target.value)}
            id="login-name-input"
            style={{ borderRadius: 'var(--r-md)', fontSize: 13 }}
          />
        </div>

        {/* Branch Select */}
        <div style={{ marginBottom: 28 }}>
          <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-400)', textTransform: 'uppercase', letterSpacing: '0.08em', display: 'block', marginBottom: 8 }}>
            Chi nhánh
          </label>
          <select
            className="input-field select-field"
            value={branch}
            onChange={e => setBranch(e.target.value)}
            id="login-branch-select"
            style={{ borderRadius: 'var(--r-md)', fontSize: 13 }}
          >
            {BRANCHES.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
        </div>

        {/* Login Button */}
        <button
          className="btn btn-primary w-full"
          style={{
            justifyContent: 'center',
            padding: '12px',
            fontSize: 14,
            fontWeight: 500,
            borderRadius: 'var(--r-md)',
            opacity: (!selectedRole || !name.trim()) ? 0.4 : 1,
            background: 'var(--gold-500)',
            boxShadow: 'none',
            transition: 'all 0.2s',
            display: 'flex',
            alignItems: 'center',
            gap: 8
          }}
          onClick={handleLogin}
          disabled={!selectedRole || !name.trim() || loading}
          id="btn-login"
        >
          {loading ? (
            <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 14, height: 14, border: '2px solid currentColor', borderTopColor: 'transparent', borderRadius: '50%', display: 'inline-block', animation: 'spin 0.8s linear infinite' }} />
              Đang đăng nhập...
            </span>
          ) : (
            <>
              {selectedRole ? getRoleIcon(selectedRole, undefined, 15) : <Lock size={15} />}
              Đăng nhập hệ thống
            </>
          )}
        </button>

        <div style={{ marginTop: 24, padding: 12, background: 'rgba(255,255,255,0.015)', borderRadius: 'var(--r-md)', border: '1px solid var(--surface-border)' }}>
          <div style={{ fontSize: 10, color: 'var(--text-400)', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Shield size={12} style={{ color: 'var(--gold-500)', flexShrink: 0 }} />
            Hệ thống bảo mật y tế · Dữ liệu được mã hóa đầu cuối
          </div>
        </div>
      </div>
    </div>
  );
}
