// === TYPES & MOCK DATA ===

export type Role =
  | 'bod'
  | 'quan_ly'
  | 'le_tan'
  | 'bac_si'
  | 'cskh'
  | 'ktv';

export interface User {
  id: string;
  name: string;
  role: Role;
  branch?: string;
  avatar: string;
}

export interface RoleConfig {
  label: string;
  desc: string;
  icon: string;
  color: string;
  allowedRoutes: string[];
}

export const ROLES: Record<Role, RoleConfig> = {
  bod: {
    label: 'Ban Giám Đốc',
    desc: 'Toàn quyền xem báo cáo',
    icon: 'Crown',
    color: '#e8a020',
    allowedRoutes: ['/', '/bao-cao', '/scheduling', '/automation', '/ho-so', '/kpi'],
  },
  quan_ly: {
    label: 'Quản Lý Chi Nhánh',
    desc: 'Quản lý vận hành cơ sở',
    icon: 'Building2',
    color: '#3b82f6',
    allowedRoutes: ['/', '/bao-cao', '/scheduling', '/automation', '/kpi', '/van-hanh'],
  },
  le_tan: {
    label: 'Lễ Tân',
    desc: 'Điều phối lịch hẹn',
    icon: 'Calendar',
    color: '#22c55e',
    allowedRoutes: ['/scheduling'],
  },
  bac_si: {
    label: 'Bác Sĩ Da Liễu',
    desc: 'Hồ sơ điều trị bệnh nhân',
    icon: 'Stethoscope',
    color: '#06b6d4',
    allowedRoutes: ['/ho-so', '/'],
  },
  cskh: {
    label: 'Chăm Sóc Khách Hàng',
    desc: 'Tự động hóa & Lead routing',
    icon: 'MessageSquare',
    color: '#a855f7',
    allowedRoutes: ['/automation', '/'],
  },
  ktv: {
    label: 'Kỹ Thuật Viên',
    desc: 'Lịch ca & KPI cá nhân',
    icon: 'Award',
    color: '#f59e0b',
    allowedRoutes: ['/kpi', '/scheduling', '/van-hanh'],
  },
};

// --- Mock Branches ---
export const BRANCHES = [
  'Tất cả chi nhánh',
  'HN - Hàng Bài',
  'HN - Kim Mã',
  'HCM - Nguyễn Thị Minh Khai',
  'HCM - Đinh Tiên Hoàng',
  'HCM - Lê Văn Sỹ',
];

// --- Mock KPI Data ---
export const kpiData = {
  doanhThuHomNay: 487_000_000,
  doanhThuThang: 8_240_000_000,
  khachHienTai: 34,
  tongLichHen: 127,
  luocHuy: 8,
  hieuSuatMay: 78,
  csatScore: 4.7,
  npsScore: 72,
  churnRisk: 23,
  doanThuCheo: 342_000_000,
};

// --- Mock Revenue Chart ---
export const revenueData = Array.from({ length: 30 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() - (29 - i));
  return {
    ngay: `${d.getDate()}/${d.getMonth() + 1}`,
    giamBeo: Math.floor(50 + Math.random() * 120) * 1_000_000,
    treHoa: Math.floor(80 + Math.random() * 160) * 1_000_000,
    triNam: Math.floor(20 + Math.random() * 60) * 1_000_000,
    chamSoc: Math.floor(10 + Math.random() * 40) * 1_000_000,
  };
});

// --- Mock Machine Utilization ---
export const machineData = [
  { name: 'Thermage FLX', utilization: 84, sessions: 6, status: 'Đang chạy' },
  { name: 'Ultherapy Prime', utilization: 72, sessions: 5, status: 'Đang chạy' },
  { name: 'AI Slimtech', utilization: 90, sessions: 8, status: 'Đang chạy' },
  { name: 'Laser Revlite', utilization: 65, sessions: 4, status: 'Rảnh' },
  { name: 'FOTONA 4D', utilization: 55, sessions: 3, status: 'Bảo trì' },
  { name: 'Exion', utilization: 78, sessions: 6, status: 'Đang chạy' },
];

// --- Mock Branch Revenue ---
export const branchData = [
  { name: 'HN - Hàng Bài', revenue: 2_140_000_000, growth: 12 },
  { name: 'HN - Kim Mã', revenue: 1_860_000_000, growth: 8 },
  { name: 'HCM - NTMK', revenue: 1_920_000_000, growth: 15 },
  { name: 'HCM - ĐTH', revenue: 1_380_000_000, growth: -3 },
  { name: 'HCM - LVS', revenue: 940_000_000, growth: 22 },
];

// --- Mock Churn Risk Customers ---
export const churnRiskData = [
  { name: 'Nguyễn Thị Lan', lastVisit: '45 ngày trước', package: 'Thermage FLX', risk: 'Cao', remaining: 2 },
  { name: 'Trần Minh Châu', lastVisit: '38 ngày trước', package: 'AI Slimtech', risk: 'Cao', remaining: 1 },
  { name: 'Lê Thu Hà', lastVisit: '31 ngày trước', package: 'Laser Revlite', risk: 'Trung bình', remaining: 3 },
  { name: 'Phạm Bích Ngọc', lastVisit: '28 ngày trước', package: 'Ultherapy', risk: 'Trung bình', remaining: 2 },
  { name: 'Vũ Hoàng Oanh', lastVisit: '22 ngày trước', package: 'Trị nám US Mela', risk: 'Thấp', remaining: 5 },
];

// --- Mock Bookings for Scheduling ---
export const HOURS = ['8:00','9:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00'];
export const ROOMS = [
  { id: 'r1', name: 'Phòng máy 1', type: 'Thermage FLX', floor: 'Tầng 2', current_status: 'available' },
  { id: 'r2', name: 'Phòng máy 2', type: 'Ultherapy Prime', floor: 'Tầng 2', current_status: 'in_use' },
  { id: 'r3', name: 'Phòng máy 3', type: 'AI Slimtech', floor: 'Tầng 3', current_status: 'cleaning' },
  { id: 'r4', name: 'Phòng máy 4', type: 'Laser Revlite', floor: 'Tầng 3', current_status: 'available' },
  { id: 'r5', name: 'Phòng 5', type: 'Chăm sóc da', floor: 'Tầng 1', current_status: 'maintenance' },
  { id: 'r6', name: 'Phòng 6', type: 'Chăm sóc da', floor: 'Tầng 1', current_status: 'available' },
];

export interface Booking {
  id: string;
  roomId: string;
  hourIndex: number;
  duration: number;
  clientName: string;
  service: string;
  status: 'occupied' | 'available' | 'maintenance' | 'waiting_prep';
  ktv: string;
  eMedicalStatus?: 'pending' | 'completed';
  checkinMethod?: 'qr' | 'faceid';
}

export const mockBookings: Booking[] = [
  { id: 'b1', roomId: 'r1', hourIndex: 0, duration: 2, clientName: 'Nguyễn Thị Lan', service: 'Thermage FLX', status: 'occupied', ktv: 'KTV Hoa', eMedicalStatus: 'completed', checkinMethod: 'faceid' },
  { id: 'b2', roomId: 'r1', hourIndex: 3, duration: 2, clientName: 'Trần Minh Châu', service: 'Thermage FLX', status: 'waiting_prep', ktv: 'KTV Hoa', eMedicalStatus: 'pending' },
  { id: 'b3', roomId: 'r2', hourIndex: 1, duration: 3, clientName: 'Lê Thu Hà', service: 'Ultherapy', status: 'occupied', ktv: 'KTV Linh', eMedicalStatus: 'completed' },
  { id: 'b4', roomId: 'r3', hourIndex: 0, duration: 2, clientName: 'Phạm Bích Ngọc', service: 'Slimtech', status: 'occupied', ktv: 'KTV Tuấn', eMedicalStatus: 'completed' },
  { id: 'b5', roomId: 'r3', hourIndex: 4, duration: 2, clientName: 'Vũ Hoàng Oanh', service: 'Slimtech', status: 'waiting_prep', ktv: 'KTV Tuấn', eMedicalStatus: 'completed' },
  { id: 'b6', roomId: 'r4', hourIndex: 2, duration: 1, clientName: 'Hoàng Mỹ Linh', service: 'Laser Revlite', status: 'occupied', ktv: 'KTV Mai', eMedicalStatus: 'completed' },
  { id: 'b7', roomId: 'r5', hourIndex: 6, duration: 2, clientName: 'Đặng Thu Thủy', service: 'Phi kim căng bóng', status: 'occupied', ktv: 'KTV Nhung', eMedicalStatus: 'completed' },
  { id: 'b8', roomId: 'r6', hourIndex: 5, duration: 3, clientName: 'Bảo trì định kỳ', service: 'Bảo trì', status: 'maintenance', ktv: '-' },
];

// --- Mock Patients ---
export const mockPatients = [
  {
    id: 'p1', name: 'Nguyễn Thị Lan', age: 42, phone: '090 123 4567',
    skinType: 'Da hỗn hợp', allergy: 'Không có', package: 'Thermage FLX',
    sessions: 6, sessionsLeft: 2, lastVisit: '12/05/2026',
    doctor: 'BS. Nguyễn Minh Anh',
    history: [
      { date: '12/05/2026', treatment: 'Thermage FLX - Buổi 4', note: 'Da cải thiện rõ rệt, nâng cơ vùng má. Tiếp tục phác đồ.' },
      { date: '28/04/2026', treatment: 'Thermage FLX - Buổi 3', note: 'Kết quả tốt, khách hàng hài lòng. Giảm nhăn vùng trán ~30%.' },
      { date: '10/04/2026', treatment: 'Thermage FLX - Buổi 2', note: 'Da bắt đầu săn chắc hơn. Không có phản ứng phụ.' },
    ],
    aiRec: 'Sau Thermage FLX, khuyến nghị bổ sung S-Glow Collagen để tối ưu độ đàn hồi da. Xem xét thêm IV Vitamin C tại REVIV để tăng hiệu quả tái tạo collagen từ bên trong.',
    loyaltyTier: 'Diamond', loyaltyPoints: 12450, affiliateCode: 'LANNGUYEN_01', referralCount: 3
  },
  {
    id: 'p2', name: 'Trần Minh Châu', age: 36, phone: '091 234 5678',
    skinType: 'Da nhạy cảm', allergy: 'Nước hoa tổng hợp', package: 'AI Slimtech',
    sessions: 10, sessionsLeft: 1, lastVisit: '15/05/2026',
    doctor: 'BS. Trần Thu Thảo',
    history: [
      { date: '15/05/2026', treatment: 'AI Slimtech - Buổi 9', note: 'Giảm 2.5cm vòng eo so với buổi đầu. Khách rất hài lòng.' },
      { date: '01/05/2026', treatment: 'AI Slimtech - Buổi 8', note: 'Giảm 2cm vòng bắp đùi. Không có tác dụng phụ.' },
    ],
    aiRec: 'Khuyến nghị gói duy trì Firming 3X sau khi hoàn thành AI Slimtech. Xem xét liệu trình IV Detox tại REVIV để tăng đào thải độc tố sau giảm béo.',
    loyaltyTier: 'Gold', loyaltyPoints: 5400, affiliateCode: 'CHAU_SLIM', referralCount: 1
  },
  {
    id: 'p3', name: 'Lê Thu Hà', age: 38, phone: '092 345 6789',
    skinType: 'Da khô', allergy: 'Không có', package: 'Laser Revlite',
    sessions: 8, sessionsLeft: 3, lastVisit: '18/05/2026',
    doctor: 'BS. Nguyễn Minh Anh',
    history: [
      { date: '18/05/2026', treatment: 'Laser Revlite - Buổi 5', note: 'Nám giảm ~40%. Tàn nhang mờ đi rõ rệt. Tiếp tục.' },
    ],
    aiRec: 'Kết hợp Trị nám Split Light để tăng hiệu quả phân tách sắc tố. Bổ sung Trị nám sinh học đa lớp nếu nám tái phát sau liệu trình.',
    loyaltyTier: 'Silver', loyaltyPoints: 1200, affiliateCode: 'HALELASER', referralCount: 0
  },
];

// --- Mock KTV Leaderboard ---
export const ktvLeaderboard = [
  { name: 'Lê Thị Hoa', branch: 'HN - Hàng Bài', sessions: 142, revenue: 284_000_000, csat: 4.9, commission: 14_200_000 },
  { name: 'Nguyễn Thị Linh', branch: 'HCM - NTMK', sessions: 138, revenue: 261_000_000, csat: 4.8, commission: 13_050_000 },
  { name: 'Trần Văn Tuấn', branch: 'HN - Kim Mã', sessions: 131, revenue: 245_000_000, csat: 4.7, commission: 12_250_000 },
  { name: 'Phạm Thị Mai', branch: 'HCM - ĐTH', sessions: 119, revenue: 228_000_000, csat: 4.8, commission: 11_400_000 },
  { name: 'Vũ Thị Nhung', branch: 'HCM - LVS', sessions: 112, revenue: 198_000_000, csat: 4.6, commission: 9_900_000 },
  { name: 'Đặng Minh Khoa', branch: 'HN - Hàng Bài', sessions: 98, revenue: 176_000_000, csat: 4.5, commission: 8_800_000 },
];

// --- Lead Routing Data ---
export const leadData = {
  total: 342,
  converted: 87,
  pending: 156,
  lost: 99,
  byChannel: [
    { channel: 'Facebook', count: 142, color: '#3b82f6' },
    { channel: 'Zalo OA', count: 98, color: '#22c55e' },
    { channel: 'Website', count: 67, color: '#a855f7' },
    { channel: 'Hotline', count: 35, color: '#f59e0b' },
  ],
  consultants: [
    { name: 'Tư vấn A - Hoa', leads: 89, converted: 31 },
    { name: 'Tư vấn B - Lan', leads: 78, converted: 24 },
    { name: 'Tư vấn C - Mai', leads: 72, converted: 19 },
    { name: 'Tư vấn D - Hùng', leads: 65, converted: 13 },
  ],
};

// --- Automation Rules ---
export const automationRules = [
  { id: 'a1', name: 'Nhắc lịch hẹn trước 24h', trigger: 'Trước lịch hẹn 24 giờ', action: 'Gửi Zalo + SMS', status: true, sent: 1247 },
  { id: 'a2', name: 'Chăm sóc sau liệu trình Laser', trigger: 'Sau check-out điều trị Laser', action: 'Gửi Zalo hướng dẫn dưỡng da', status: true, sent: 876 },
  { id: 'a3', name: 'Chăm sóc sau Giảm béo', trigger: 'Sau check-out điều trị Giảm béo', action: 'Gửi Zalo hướng dẫn ăn uống', status: true, sent: 643 },
  { id: 'a4', name: 'Cảnh báo Churn Risk', trigger: 'Khách không check-in > 30 ngày', action: 'Alert CSKH + Gửi voucher', status: true, sent: 234 },
  { id: 'a5', name: 'Gợi ý tái ký liệu trình', trigger: 'Còn 1 buổi cuối trong gói', action: 'Gửi offer tái ký ưu đãi 10%', status: false, sent: 0 },
  { id: 'a6', name: 'Chúc mừng sinh nhật VIP', trigger: 'Trước sinh nhật KH VIP 3 ngày', action: 'Gửi Zalo + Voucher sinh nhật', status: true, sent: 89 },
  { id: 'a7', name: 'Gửi Link Đánh Giá (Rating)', trigger: 'Sau check-out 2 tiếng', action: 'Gửi Zalo form 5 sao', status: true, sent: 432 },
];

// --- Staff Operations (Task List & F&B Orders) ---
export const mockStaffTasks = [
  { id: 't1', room: 'Phòng máy 1', task: 'Chuẩn bị đầu tip Thermage FLX 900', status: 'pending', priority: 'high', assignee: 'KTV Hoa', time: '10:45' },
  { id: 't2', room: 'Phòng 5', task: 'Sát khuẩn tia cực tím & Chuẩn bị tinh dầu', status: 'completed', priority: 'medium', assignee: 'KTV Nhung', time: '09:30' },
  { id: 't3', room: 'Phòng máy 3', task: 'Bảo trì định kỳ AI Slimtech', status: 'in-progress', priority: 'high', assignee: 'Kỹ thuật viên', time: '14:00' },
  { id: 't4', room: 'Phòng chờ VIP', task: 'F&B Order: 2 Trà Hoa Cúc Mật Ong', status: 'pending', priority: 'medium', assignee: 'Lễ Tân', time: '11:15' },
];

// --- Finance Transactions (Auto-Banking Import) ---
export interface Transaction {
  transaction_id: string;
  booking_id?: string;
  customer_id?: string;
  total_amount: number;
  revenue_type: 'package_sale' | 'single_service' | 'product_sale';
  staff_commissions: any[];
  payment_method: 'cash' | 'credit_card' | 'installment' | 'bank_transfer';
  status: 'completed' | 'refunded' | 'matched' | 'categorized_ai' | 'pending_audit';
  
  // Legacy fields
  id: string;
  time: string;
  amount: number;
  type: string;
  bank: string;
  content: string;
  category: string;
}

export const mockTransactions: Transaction[] = [
  { transaction_id: 'tx1', id: 'tx1', time: '10:24', amount: 45000000, type: 'Chuyển khoản', bank: 'Vietcombank', content: 'Nguyen Thi Lan TT Thermage', category: 'Doanh thu dịch vụ', status: 'matched', total_amount: 45000000, revenue_type: 'package_sale', staff_commissions: [{staff_id: 'NV01', role: 'doctor', type: 'percentage', value: 10}], payment_method: 'bank_transfer' },
  { transaction_id: 'tx2', id: 'tx2', time: '09:15', amount: 12000000, type: 'Quẹt thẻ', bank: 'Techcombank', content: 'Thanh toan the POS', category: 'Doanh thu dịch vụ', status: 'matched', total_amount: 12000000, revenue_type: 'single_service', staff_commissions: [{staff_id: 'NV02', role: 'ktv', type: 'fixed', value: 50000}], payment_method: 'credit_card' },
  { transaction_id: 'tx3', id: 'tx3', time: '08:40', amount: -3500000, type: 'Chuyển khoản', bank: 'MB Bank', content: 'Thanh toan tien dien Thang 5', category: 'Chi phí vận hành', status: 'categorized_ai', total_amount: -3500000, revenue_type: 'single_service', staff_commissions: [], payment_method: 'bank_transfer' },
  { transaction_id: 'tx4', id: 'tx4', time: 'Hôm qua', amount: 80000000, type: 'Tiền mặt', bank: '-', content: 'Chau TT goi AI Slimtech', category: 'Doanh thu dịch vụ', status: 'pending_audit', total_amount: 80000000, revenue_type: 'package_sale', staff_commissions: [], payment_method: 'cash' },
];

// --- Incident & Ticket System ---
export interface Ticket {
  ticket_id: string;
  customer_id: string;
  booking_id?: string;
  issue_category: 'service_quality' | 'staff_attitude' | 'facility' | 'medical_incident';
  severity_level: 'low' | 'medium' | 'high' | 'critical';
  assigned_to: string;
  status: 'open' | 'investigating' | 'resolved' | 'closed';
  resolution_notes: string;
  
  // UI Display helpers
  customer_name: string;
  created_at: string;
  description: string;
}

export const mockTickets: Ticket[] = [
  { ticket_id: 'tc1', customer_id: 'p1', customer_name: 'Nguyễn Thị Lan', issue_category: 'medical_incident', severity_level: 'critical', assigned_to: 'Giám đốc Vận hành', status: 'investigating', resolution_notes: '', created_at: '10 phút trước', description: 'Khách báo bị rát da vùng má sau khi bắn Thermage FLX.' },
  { ticket_id: 'tc2', customer_id: 'p2', customer_name: 'Trần Minh Châu', issue_category: 'facility', severity_level: 'medium', assigned_to: 'Quản lý Chi nhánh', status: 'open', resolution_notes: '', created_at: '2 giờ trước', description: 'Khách phàn nàn điều hòa phòng VIP 3 không mát.' },
  { ticket_id: 'tc3', customer_id: 'p3', customer_name: 'Lê Thu Hà', issue_category: 'service_quality', severity_level: 'low', assigned_to: 'CSKH Trưởng', status: 'resolved', resolution_notes: 'Đã gửi SMS xin lỗi tự động và gọi điện tặng voucher 1 triệu.', created_at: 'Hôm qua', description: 'Đánh giá 3 sao trên Zalo OA: "Chờ lấy xe lâu".' },
];

// --- Inventory & Medical Supplies ---
export const mockInventory = [
  { id: 'inv1', name: 'Đầu tip Thermage FLX 900', category: 'Vật tư CNC', unit: 'Cái', stock: 12, minStock: 5, value: 45000000, status: 'normal' },
  { id: 'inv2', name: 'Kim tiêm Meso 34G', category: 'Vật tư Y tế', unit: 'Hộp', stock: 3, minStock: 10, value: 350000, status: 'low' },
  { id: 'inv3', name: 'Kem phục hồi B5 ZinC', category: 'Mỹ phẩm', unit: 'Tuýp', stock: 45, minStock: 20, value: 850000, status: 'normal' },
  { id: 'inv4', name: 'Dưỡng chất Exosome', category: 'Dưỡng chất tiêm', unit: 'Lọ', stock: 1, minStock: 15, value: 3200000, status: 'critical' },
  { id: 'inv5', name: 'Gel siêu âm Laser', category: 'Vật tư Y tế', unit: 'Can 5L', stock: 24, minStock: 5, value: 400000, status: 'normal' },
];
