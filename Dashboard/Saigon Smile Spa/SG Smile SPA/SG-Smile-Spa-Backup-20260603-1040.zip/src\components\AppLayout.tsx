import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth, getRoleIcon } from '../AuthContext';
import { ROLES, type Role } from '../data';
import {
  LayoutDashboard, BarChart3, Calendar, Zap,
  FileText, Trophy, LogOut, Bell, Search, Menu, X, Sparkles, ClipboardCheck, Smartphone, Package, DollarSign, ShieldAlert
} from 'lucide-react';

const NAV_ITEMS = [
  { path: '/', label: 'Tổng quan', icon: LayoutDashboard, roles: ['bod', 'quan_ly', 'bac_si', 'cskh'] },
  { path: '/bao-cao', label: 'Báo cáo', icon: BarChart3, roles: ['bod', 'quan_ly'] },
  { path: '/scheduling', label: 'Lịch hẹn & Phòng', icon: Calendar, roles: ['bod', 'quan_ly', 'le_tan', 'ktv'] },
  { path: '/automation', label: 'Tự động hoá', icon: Zap, roles: ['bod', 'quan_ly', 'cskh'] },
  { path: '/ho-so', label: 'Hồ sơ bệnh nhân', icon: FileText, roles: ['bod', 'quan_ly', 'bac_si'] },
  { path: '/kpi', label: 'KPI & Hoa hồng', icon: Trophy, roles: ['bod', 'quan_ly', 'ktv'] },
  { path: '/van-hanh', label: 'Vận hành / Task', icon: ClipboardCheck, roles: ['bod', 'quan_ly', 'ktv'] },
  { path: '/kho', label: 'Kho & Tài sản', icon: Package, roles: ['bod', 'quan_ly'] },
  { path: '/tai-chinh', label: 'Tài chính & Đối soát', icon: DollarSign, roles: ['bod', 'quan_ly'] },
  { path: '/khieu-nai', label: 'Khiếu nại & Sự cố', icon: ShieldAlert, roles: ['bod', 'quan_ly', 'cskh'] },
];

interface LayoutProps { children: React.ReactNode; title: string; subtitle?: string; }

export default function AppLayout({ children, title, subtitle }: LayoutProps) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifications] = useState(3);

  const allowedNav = NAV_ITEMS.filter(item =>
    user && item.roles.includes(user.role)
  );

  const handleLogout = () => { logout(); navigate('/login'); };

  const roleConfig = user ? ROLES[user.role as Role] : null;

  return (
    <div className="app-layout">
      {/* SIDEBAR */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-logo">
          <div className="sidebar-logo-icon" style={{ background: 'rgba(190, 146, 77, 0.08)', border: '1px solid rgba(190, 146, 77, 0.2)', boxShadow: 'none' }}>
            <Sparkles size={16} color="var(--gold-400)" />
          </div>
          <div className="sidebar-logo-text">
            <div className="brand">Saigon Smile Medical</div>
            <div className="sub">Hệ thống nội bộ</div>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div className="nav-section-label">Menu chính</div>
          {allowedNav.map(item => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <button
                key={item.path}
                className={`nav-item ${isActive ? 'active' : ''}`}
                onClick={() => { navigate(item.path); setSidebarOpen(false); }}
                id={`nav-${item.path.replace('/', '') || 'home'}`}
              >
                <Icon className="nav-icon" size={18} />
                <span className="nav-label">{item.label}</span>
                {item.path === '/automation' && <span className="nav-badge">3</span>}
              </button>
            );
          })}
          
          <div className="nav-section-label" style={{ marginTop: 24 }}>Khách Hàng (Demo)</div>
          <button className="nav-item" style={{ color: 'var(--purple)' }} onClick={() => window.open('/app', '_blank')}>
            <Smartphone size={18} strokeWidth={1.5} />
            <span className="nav-label">Super App (Mobile)</span>
          </button>
        </nav>

        <div className="sidebar-footer">
          <div className="user-chip">
            <div className="user-avatar">{user?.avatar}</div>
            <div className="user-info">
              <div className="user-name">{user?.name}</div>
              <div className="user-role" style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                {user && getRoleIcon(user.role as Role, undefined, 11)}
                <span>{roleConfig?.label}</span>
              </div>
            </div>
            <button
              onClick={handleLogout}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-400)', padding: 4 }}
              title="Đăng xuất"
              id="btn-logout"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 99 }}
        />
      )}

      {/* MAIN CONTENT */}
      <div className="main-content">
        {/* HEADER */}
        <header className="header">
          <button
            className="btn-icon"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{ display: 'none' }}
            id="btn-menu-toggle"
          >
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>

          <div className="header-title">
            <h1>{title}</h1>
            {subtitle && <p>{subtitle}</p>}
          </div>

          <div className="header-actions">
            {/* Branch tag */}
            {user?.branch && (
              <div style={{
                padding: '4px 12px', background: 'var(--surface-1)',
                border: '1px solid var(--surface-border)',
                borderRadius: 'var(--r-full)', fontSize: 12, color: 'var(--text-300)'
              }}>
                📍 {user.branch}
              </div>
            )}

            <div className="btn-icon" id="btn-search" title="Tìm kiếm">
              <Search size={16} />
            </div>

            <div className="btn-icon" id="btn-notifications" style={{ position: 'relative' }}>
              <Bell size={16} />
              {notifications > 0 && <span className="notification-dot" />}
            </div>
          </div>
        </header>

        {/* PAGE CONTENT */}
        <main className="page-container">
          {children}
        </main>
      </div>
    </div>
  );
}
