import React, { useState, useEffect } from 'react';
import AppLayout from '../components/AppLayout';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, Legend
} from 'recharts';
import {
  kpiData, revenueData, machineData, branchData, churnRiskData, BRANCHES, mockTransactions
} from '../data';
import { TrendingUp, TrendingDown, Users, Clock, Cpu, AlertTriangle, DollarSign, Star, Building2, MapPin, Smile, BarChart3, Link2, Sparkles, CreditCard, ArrowDownRight, ArrowUpRight } from 'lucide-react';

const fmt = (n: number) => {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1)}Tỷ`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(0)}Tr`;
  return n.toLocaleString('vi-VN');
};

const COLORS_SERVICE = ['#e8a020', '#3b82f6', '#22c55e', '#a855f7'];
const COLORS_BRANCH = ['#e8a020', '#3b82f6', '#22c55e', '#f59e0b', '#06b6d4'];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div style={{ background: 'var(--bg-600)', border: '1px solid var(--surface-border)', borderRadius: 8, padding: '10px 14px', fontSize: 12 }}>
        <div style={{ color: 'var(--text-300)', marginBottom: 4, fontWeight: 600 }}>{label}</div>
        {payload.map((p: any) => (
          <div key={p.name} style={{ color: p.color, marginBottom: 2 }}>
            {p.name}: {fmt(p.value)}đ
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function DashboardPage() {
  const [branch, setBranch] = useState(BRANCHES[0]);
  const [animated, setAnimated] = useState(false);

  useEffect(() => { setTimeout(() => setAnimated(true), 100); }, []);

  const pieMachineData = machineData.map(m => ({
    name: m.name,
    value: m.utilization,
    sessions: m.sessions,
  }));

  const crossSellData = [
    { name: 'Spa → REVIV', value: 68 },
    { name: 'Spa → USAC', value: 31 },
    { name: 'REVIV → Spa', value: 44 },
    { name: 'USAC → Spa', value: 22 },
  ];

  return (
    <AppLayout
      title="Tổng quan Vận hành"
      subtitle={`Cập nhật: ${new Date().toLocaleDateString('vi-VN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`}
    >
      {/* Branch Filter */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-2">
          {BRANCHES.slice(0, 4).map(b => (
            <button
              key={b}
              onClick={() => setBranch(b)}
              className={`btn btn-sm ${branch === b ? 'btn-primary' : 'btn-secondary'}`}
              id={`filter-branch-${b.replace(/\s/g, '-')}`}
              style={{ display: 'flex', alignItems: 'center', gap: 6, borderRadius: 'var(--r-sm)', fontSize: 11, padding: '6px 12px' }}
            >
              {b === 'Tất cả chi nhánh' ? <Building2 size={12} /> : <MapPin size={12} />}
              {b}
            </button>
          ))}
        </div>
        <div style={{ fontSize: 11, color: 'var(--text-400)', display: 'flex', alignItems: 'center', gap: 4 }}>
          <Clock size={12} />
          Cập nhật tự động mỗi 5 phút
        </div>
      </div>

      {/* KPI Metrics Row */}
      <div className="grid-4 mb-6">
        {[
          { label: 'Doanh thu hôm nay', value: fmt(kpiData.doanhThuHomNay) + 'đ', sub: '+12% so hôm qua', trend: 'up', icon: DollarSign, color: 'gold', cls: 'stagger-1' },
          { label: 'Khách đang phục vụ', value: `${kpiData.khachHienTai} khách`, sub: `${kpiData.tongLichHen} lịch hẹn hôm nay`, trend: 'up', icon: Users, color: 'green', cls: 'stagger-2' },
          { label: 'Hiệu suất máy móc', value: `${kpiData.hieuSuatMay}%`, sub: '5/6 máy đang hoạt động', trend: 'up', icon: Cpu, color: 'blue', cls: 'stagger-3' },
          { label: 'Nguy cơ rời bỏ', value: `${kpiData.churnRisk} KH`, sub: 'Cần chăm sóc khẩn cấp', trend: 'down', icon: AlertTriangle, color: 'red', cls: 'stagger-4' },
        ].map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div key={i} className={`metric-card ${kpi.color} animate-fade-up ${kpi.cls}`}>
              <div className={`metric-icon ${kpi.color}`}>
                <Icon size={20} />
              </div>
              <div className="metric-label">{kpi.label}</div>
              <div className="metric-value">{animated ? kpi.value : '—'}</div>
              <div className="metric-sub">
                <span className={`metric-trend ${kpi.trend}`}>
                  {kpi.trend === 'up' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                  {kpi.sub}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Secondary KPIs */}
      <div className="grid-4 mb-6">
        {[
          { label: 'Doanh thu tháng', value: fmt(kpiData.doanhThuThang) + 'đ', icon: DollarSign, color: 'var(--gold-400)' },
          { label: 'Điểm CSAT', value: `${kpiData.csatScore}/5.0`, icon: Smile, color: 'var(--green)' },
          { label: 'NPS Score', value: `${kpiData.npsScore}`, icon: BarChart3, color: 'var(--blue)' },
          { label: 'Doanh thu bán chéo', value: fmt(kpiData.doanThuCheo) + 'đ', icon: Link2, color: 'var(--purple)' },
        ].map((item, i) => {
          const Icon = item.icon;
          return (
            <div key={i} className="card animate-fade-up" style={{ animationDelay: `${(i + 5) * 0.05}s`, background: 'var(--bg-800)', border: '1px solid var(--surface-border)', padding: '16px 20px', borderRadius: 'var(--r-md)' }}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="metric-label" style={{ fontSize: 11, fontWeight: 500, color: 'var(--text-400)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{item.label}</div>
                  <div style={{ fontSize: 20, fontWeight: 600, color: 'var(--text-100)', marginTop: 4, letterSpacing: '-0.02em' }}>{item.value}</div>
                </div>
                <div style={{ color: item.color, opacity: 0.8 }}><Icon size={20} strokeWidth={1.8} /></div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Charts Row */}
      <div className="grid-2 mb-6">
        {/* Revenue Chart */}
        <div className="card col-span-2 animate-fade-up stagger-2">
          <div className="flex items-center justify-between mb-4">
            <div className="card-title">
              <span className="card-title-dot" />
              Doanh thu 30 ngày qua (theo dịch vụ)
            </div>
            <div className="flex gap-2">
              {['Tháng này', 'Tháng trước', 'Quý này'].map(t => (
                <button key={t} className="btn btn-sm btn-ghost">{t}</button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={revenueData.slice(-14)} margin={{ top: 5, right: 10, bottom: 5, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="ngay" tick={{ fill: 'var(--text-500)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text-500)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `${(v/1000000).toFixed(0)}Tr`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12, color: 'var(--text-400)' }} />
              <Line type="monotone" dataKey="giamBeo" name="Giảm béo" stroke="#e8a020" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="treHoa" name="Trẻ hóa da" stroke="#3b82f6" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="triNam" name="Trị nám" stroke="#22c55e" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="chamSoc" name="Chăm sóc" stroke="#a855f7" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Dynamic Pricing AI Banner */}
      <div style={{ padding: '12px 20px', background: 'rgba(232,160,32,0.05)', border: '1px solid rgba(232,160,32,0.2)', borderRadius: 'var(--r-md)', marginBottom: 24, display: 'flex', alignItems: 'center', gap: 16 }} className="animate-fade-up">
        <Sparkles size={20} color="var(--gold-400)" strokeWidth={1.5} style={{ flexShrink: 0 }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--gold-400)', marginBottom: 2 }}>Chiến lược Giá linh hoạt (Dynamic Pricing)</div>
          <div style={{ fontSize: 12, color: 'var(--text-300)' }}>Dự báo công suất chiều nay chỉ đạt <strong style={{ color: 'var(--text-100)' }}>45%</strong>. Đề xuất: Giảm <strong style={{ color: 'var(--green)' }}>15%</strong> khung giờ 14:00-16:00 trên Zalo ZNS để lấp đầy phòng.</div>
        </div>
        <button className="btn btn-primary btn-sm" style={{ borderRadius: 'var(--r-sm)', fontSize: 11, padding: '6px 12px' }}>Kích hoạt Campaign</button>
      </div>

      <div className="grid-3 mb-6">
        {/* Machine Utilization */}
        <div className="card animate-fade-up stagger-1">
          <div className="card-title"><span className="card-title-dot" />Hiệu suất máy móc</div>
          {machineData.map((m, i) => (
            <div key={i} style={{ marginBottom: 14 }}>
              <div className="flex justify-between text-sm mb-1">
                <span style={{ color: 'var(--text-200)', fontSize: 13 }}>{m.name}</span>
                <div className="flex gap-2 items-center">
                  <span className={`badge badge-${m.status === 'Đang chạy' ? 'green' : m.status === 'Bảo trì' ? 'amber' : 'blue'}`}>
                    {m.status}
                  </span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-100)' }}>{m.utilization}%</span>
                </div>
              </div>
              <div className="progress-bar-wrap" style={{ height: 6 }}>
                <div
                  className={`progress-bar ${m.utilization > 80 ? 'green' : m.utilization > 60 ? 'gold' : 'blue'}`}
                  style={{ width: `${m.utilization}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Branch Comparison */}
        <div className="card animate-fade-up stagger-2">
          <div className="card-title"><span className="card-title-dot" />Doanh thu theo chi nhánh</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={branchData} layout="vertical" margin={{ left: 10, right: 20 }}>
              <XAxis type="number" tick={{ fill: 'var(--text-500)', fontSize: 10 }} tickFormatter={v => `${(v/1000000000).toFixed(1)}Tỷ`} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="name" tick={{ fill: 'var(--text-400)', fontSize: 11 }} width={90} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v: any) => [`${fmt(Number(v))}đ`, 'Doanh thu']} contentStyle={{ background: 'var(--bg-600)', border: '1px solid var(--surface-border)', borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="revenue" radius={[0, 4, 4, 0]}>
                {branchData.map((_, i) => <Cell key={i} fill={COLORS_BRANCH[i]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Finance & Cross-sell Section */}
      <div className="grid-2">
        <div className="card animate-fade-up stagger-3">
          <div className="card-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div><span className="card-title-dot" style={{ background: 'var(--cyan)' }} />Dòng tiền & Giao dịch AI</div>
            <button className="btn btn-sm btn-icon"><Sparkles size={14} color="var(--cyan)" /></button>
          </div>
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Thời gian</th>
                  <th>Giao dịch</th>
                  <th>Số tiền</th>
                  <th>Trạng thái</th>
                </tr>
              </thead>
              <tbody>
                {mockTransactions.map((tx, i) => (
                  <tr key={i}>
                    <td style={{ fontSize: 11, color: 'var(--text-400)' }}>{tx.time}</td>
                    <td>
                      <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-100)' }}>{tx.content}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-500)' }}>{tx.bank} • {tx.type}</div>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontWeight: 600, color: tx.amount > 0 ? 'var(--green)' : 'var(--red)' }}>
                        {tx.amount > 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                        {Math.abs(tx.amount).toLocaleString('vi-VN')}đ
                      </div>
                    </td>
                    <td>
                      <span className={`badge badge-${tx.status === 'matched' ? 'success' : tx.status === 'categorized_ai' ? 'warning' : 'neutral'}`}>
                        {tx.status === 'matched' ? 'Đã khớp Bill' : tx.status === 'categorized_ai' ? 'AI Gán nhãn' : 'Chờ xác nhận'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card animate-fade-up stagger-4" style={{ display: 'flex', flexDirection: 'column' }}>
          <div className="card-title"><span className="card-title-dot" />Bán chéo hệ sinh thái</div>
          <div style={{ marginBottom: 12, padding: 12, background: 'var(--surface-1)', borderRadius: 'var(--r-md)', border: '1px solid var(--surface-border)' }}>
            <div style={{ fontSize: 11, color: 'var(--text-400)', marginBottom: 8 }}>Lượt giới thiệu trong tháng</div>
            {crossSellData.map((item, i) => (
              <div key={i} style={{ marginBottom: 10 }}>
                <div className="flex justify-between text-sm mb-1">
                  <span style={{ fontSize: 12, color: 'var(--text-300)' }}>{item.name}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-100)' }}>{item.value} KH</span>
                </div>
                <div className="progress-bar-wrap" style={{ height: 5 }}>
                  <div className="progress-bar gold" style={{ width: `${(item.value / 70) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
          <div style={{ padding: 10, background: 'rgba(232,160,32,0.03)', borderRadius: 'var(--r-md)', border: '1px solid var(--surface-border-gold)', fontSize: 12, color: 'var(--text-300)', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Sparkles size={14} color="var(--gold-400)" />
            <span>Đề xuất tự động: <strong style={{ color: 'var(--gold-400)' }}>165 cơ hội bán chéo</strong> tiềm năng tuần tới</span>
          </div>
        </div>
      </div>

      {/* Affiliate & Loyalty */}
      <div className="grid-2 mb-6">
        <div className="card animate-fade-up stagger-3">
          <div className="card-title" style={{ marginBottom: 20 }}>
            <div><span className="card-title-dot" style={{ background: 'var(--purple)' }} />Affiliate & Tăng trưởng Khách Mới</div>
          </div>
          <div className="flex gap-4 mb-4">
            <div style={{ flex: 1, padding: 16, background: 'var(--bg-800)', borderRadius: 'var(--r-md)', border: '1px solid var(--surface-border)' }}>
              <div style={{ fontSize: 12, color: 'var(--text-400)', marginBottom: 4 }}>Khách Referral (Tháng)</div>
              <div style={{ fontSize: 24, fontWeight: 700, color: 'var(--text-100)' }}>145 <span style={{ fontSize: 12, fontWeight: 400, color: 'var(--green)' }}>+12%</span></div>
            </div>
            <div style={{ flex: 1, padding: 16, background: 'var(--bg-800)', borderRadius: 'var(--r-md)', border: '1px solid var(--surface-border)' }}>
              <div style={{ fontSize: 12, color: 'var(--text-400)', marginBottom: 4 }}>Doanh thu Referral</div>
              <div style={{ fontSize: 24, fontWeight: 700, color: 'var(--purple)' }}>840Tr <span style={{ fontSize: 12, fontWeight: 400, color: 'var(--green)' }}>+8%</span></div>
            </div>
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-300)', background: 'var(--surface-1)', padding: 12, borderRadius: 'var(--r-sm)' }}>
            <strong>Đề xuất AI:</strong> Chiến dịch "Mời bạn bè - Tặng Voucher 500k" đang có tỷ lệ chuyển đổi tốt (28%). Đề xuất tăng mức hoa hồng cho khách Diamond.
          </div>
        </div>

        <div className="card animate-fade-up stagger-4">
          <div className="card-title" style={{ marginBottom: 20 }}>
            <div><span className="card-title-dot" style={{ background: 'var(--gold-400)' }} />Loyalty VIP - Hạng Thẻ</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {[
              { tier: 'Diamond', count: 124, req: 'Chi tiêu > 200Tr', color: 'linear-gradient(135deg, var(--gold-400), var(--purple))' },
              { tier: 'Gold', count: 850, req: 'Chi tiêu > 50Tr', color: 'linear-gradient(135deg, #eab308, #ca8a04)' },
              { tier: 'Silver', count: 3240, req: 'Khách mới', color: 'linear-gradient(135deg, #9ca3af, #6b7280)' }
            ].map(l => (
              <div key={l.tier} style={{ padding: 12, background: 'var(--bg-800)', borderRadius: 'var(--r-md)', border: '1px solid var(--surface-border)', ...(l.tier === 'Diamond' && { gridColumn: 'span 2' }) }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                  <div style={{ fontSize: 16, fontWeight: 700, background: l.color, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{l.tier}</div>
                  <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-100)' }}>{l.count}</div>
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-500)' }}>{l.req}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card mb-6 animate-fade-up stagger-5">
        <div className="card-title flex justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle size={16} color="var(--amber)" />
            Khách hàng Rủi ro Rời bỏ (Churn Risk &gt; 30 ngày)
          </div>
          <button className="btn btn-sm btn-secondary">Xem tất cả</button>
        </div>
        <div className="table-wrapper">
          <table className="data-table">
            <thead>
              <tr>
                <th>Khách hàng</th>
                <th>Lần thăm cuối</th>
                <th>Gói liệu trình</th>
                <th>Buổi còn lại</th>
                <th>Mức độ rủi ro</th>
                <th>Hành động</th>
              </tr>
            </thead>
            <tbody>
              {churnRiskData.map((c, i) => (
                <tr key={i}>
                  <td style={{ fontWeight: 600 }}>{c.name}</td>
                  <td style={{ color: 'var(--text-400)', fontSize: 12 }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Clock size={12} />
                      {c.lastVisit}
                    </span>
                  </td>
                  <td>{c.package}</td>
                  <td>
                    <span style={{ fontWeight: 700, color: c.remaining <= 1 ? 'var(--red)' : 'var(--amber)' }}>
                      {c.remaining} buổi
                    </span>
                  </td>
                  <td>
                    <span className={`badge badge-${c.risk === 'Cao' ? 'red' : c.risk === 'Trung bình' ? 'amber' : 'green'}`}>
                      {c.risk}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button className="btn btn-sm btn-success" style={{ borderRadius: 'var(--r-sm)', fontSize: 11, padding: '4px 10px' }}>Zalo</button>
                      <button className="btn btn-sm btn-secondary" style={{ borderRadius: 'var(--r-sm)', fontSize: 11, padding: '4px 10px' }}>Voucher</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppLayout>
  );
}
